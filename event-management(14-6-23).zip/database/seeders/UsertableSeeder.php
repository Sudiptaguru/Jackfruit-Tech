<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class UsertableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'username' => 'admin',
            'password' => bcrypt('12345678'),
            'privelege' => 'admin',
            'defaultgate' => 'pit',
            'created_by' => '1',
        ]);
    }
}
