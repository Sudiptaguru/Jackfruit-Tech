<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGeneraladmissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('generaladmissions', function (Blueprint $table) {
            $table->id();
            $table->string("tickettype", 255)->nullable();
            $table->decimal("ticketprice", 6, 2)->nullable();
            $table->boolean("is_active")->default(0);
            $table->timestamps();
        });
        Schema::create('gapitentries', function (Blueprint $table) {
            $table->id();
            $table->string("tickettype", 255)->nullable();
            $table->decimal("ticketprice", 6, 2)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('generaladmissions');
        Schema::dropIfExists('gapitentries');
    }
}
