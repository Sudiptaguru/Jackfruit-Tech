<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;
    use HasFactory;
    public $table = 'event_transaction';
    public $timestamps = false;
    protected $fillable = [
        'eventdate','transactiondate','transactiontime','transactionstatus','qtyadulttickets','qtyconcessiontickets','qtystudenttickets','qtychildtickets','qtycompanion','qtyfamilytickets','qtyprograms','qtyadultpit','qtyconcessionpit','qtystudentpit','qtychildpit','qtynominateddriver','qtyadultdriverincpit','qtyconcessiondriverincpit','qtystudentdriverincpit','totalsell','paymentmethod', 'hosttrack','user'
    ];
}
