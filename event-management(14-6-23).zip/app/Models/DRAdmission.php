<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DRAdmission extends Model
{
    use HasFactory;
    protected $table = 'dradmissions';
    protected $fillable = [
        'tickettype', 'ticketprice', 'is_active'
    ];
}
