<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Generaladmission;
use App\Models\GAPitentry;
use App\Models\Pitentry;
use App\Models\DRAdmission;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    // public function index1()
    // {
    //     $generaladmissions = Generaladmission::get();
    //     return view('home', compact('generaladmissions'));
    // }
    public function index()
    {
        $generaladmissions = Generaladmission::get();
        $gapitentries = GAPitentry::get();
        $pitentries = Pitentry::get();
        $dradmissions = DRAdmission::get();
        // return $pitentries;die;
        return view('home', compact('generaladmissions','gapitentries','pitentries','dradmissions'));
    }
    public function addToCart($id)
    {
        $admission = Generaladmission::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $admission->tickettype,
                "quantity" => 1,
                "ticketprice" => $admission->ticketprice
            ];
        }
        if($admission['is_active']==0)
        {
            session()->put('cart', $cart);
        }
        if($admission['is_active']==0)
        {
            return redirect()->back()->with('success', 'Ticket added to cart successfully!');
        }
        else
        {
            return redirect()->back()->with('error', 'Ticket is unavailable');
        }
    }
    public function addToCart1($id)
    {
        $gapitentry = GAPitentry::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $gapitentry->tickettype,
                "quantity" => 1,
                "ticketprice" => $gapitentry->ticketprice
            ];
        }

        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }
    public function addToCart2($id)
    {
        $pitentry = Pitentry::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $pitentry->tickettype,
                "quantity" => 1,
                "ticketprice" => $pitentry->ticketprice
            ];
        }

        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }
    public function addToCart3($id)
    {
        $dradmission = DRAdmission::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $dradmission->tickettype,
                "quantity" => 1,
                "ticketprice" => $dradmission->ticketprice
            ];
        }

        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function update(Request $request)
    {
        if ($request->id && $request->quantity) {
            $cart = session()->get('cart');
            $cart[$request->id]["quantity"] = $request->quantity;
            session()->put('cart', $cart);
            session()->flash('success', 'Ticket updated successfully');
        }
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function remove(Request $request)
    {
        if ($request->id) {
            $cart = session()->get('cart');
            if (isset($cart[$request->id])) {
                unset($cart[$request->id]);
                session()->put('cart', $cart);
            }
            session()->flash('success', 'Ticket removed successfully');
        }
    }
}
