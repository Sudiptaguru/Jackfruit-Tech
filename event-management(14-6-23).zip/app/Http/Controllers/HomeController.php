<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Generaladmission;
use App\Models\GAPitentry;
use App\Models\Pitentry;
use App\Models\DRAdmission;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    // public function index1()
    // {
    //     $generaladmissions = Generaladmission::get();
    //     return view('home', compact('generaladmissions'));
    // }
    public function index()
    {
        // $generaladmissions = Generaladmission::get();
        // $gapitentries = GAPitentry::get();
        // $pitentries = Pitentry::get();
        // $dradmissions = DRAdmission::get();
        return DB::table('eventlist')->get();
        // return $pitentries;die;
        // return view('home', compact('generaladmissions','gapitentries','pitentries','dradmissions'));
    }
    public function addToCart($id)
    {
        $data = [];
        // $admission = Generaladmission::findOrFail($id);
        $admission = DB::table('eventlist')->where('eventstatus', 'Active')->first();

            if($admission->hosttrack == 'Carrick' && $admission->assignedpricelist == 'Standard'){
                $data = DB::table('ticketprices_carrick_standardevent')->where('id',$id)->first();

            }elseif($admission->hosttrack == 'Carrick' && $admission->assignedpricelist == 'Custom'){
                $data = DB::table('ticketprices_carrick_customevent')->where('id',$id)->first();

            }elseif($admission->hosttrack == 'Hobart' && $admission->assignedpricelist == 'Standard'){
                $data = DB::table('ticketprices_hobart_standardevent')->where('id',$id)->first();

            }elseif($admission->hosttrack == 'Hobart' && $admission->assignedpricelist == 'Custom'){
                $data = DB::table('ticketprices_hobart_customevent')->where('id',$id)->first();

            }elseif($admission->hosttrack == 'Latrobe' && $admission->assignedpricelist == 'Standard'){
                $data = DB::table('ticketprices_latrobe_standardevent')->where('id',$id)->first();

            }elseif($admission->hosttrack == 'Latrobe' && $admission->assignedpricelist == 'Custom'){
                $data = DB::table('ticketprices_latrobe_customevent')->where('id',$id)->first();

            }

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $data->tickettype,
                "quantity" => 1,
                "ticketprice" => $data->ticketprice
            ];
        }

            session()->put('cart', $cart);

            return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }
    public function addToCart1($id)
    {
        $gapitentry = GAPitentry::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $gapitentry->tickettype,
                "quantity" => 1,
                "ticketprice" => $gapitentry->ticketprice
            ];
        }

        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }
    public function addToCart2($id)
    {
        $pitentry = Pitentry::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $pitentry->tickettype,
                "quantity" => 1,
                "ticketprice" => $pitentry->ticketprice
            ];
        }

        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }
    public function addToCart3($id)
    {
        $dradmission = DRAdmission::findOrFail($id);

        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "tickettype" => $dradmission->tickettype,
                "quantity" => 1,
                "ticketprice" => $dradmission->ticketprice
            ];
        }

        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Ticket added to cart successfully!');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function update(Request $request)
    {
        if ($request->id && $request->quantity) {
            $cart = session()->get('cart');
            $cart[$request->id]["quantity"] = $request->quantity;
            session()->put('cart', $cart);
            session()->flash('success', 'Ticket updated successfully');
        }
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function remove(Request $request)
    {
        if ($request->id) {
            $cart = session()->get('cart');
            if (isset($cart[$request->id])) {
                unset($cart[$request->id]);
                session()->put('cart', $cart);
            }
            session()->flash('success', 'Ticket removed successfully');
        }
    }
}
