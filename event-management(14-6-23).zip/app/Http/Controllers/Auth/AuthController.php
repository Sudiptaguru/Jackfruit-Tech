<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Session;
use App\Models\User;
use App\Models\UserVerify;
use App\Models\Generaladmission;
use App\Models\GAPitentry;
use App\Models\Pitentry;
use App\Models\DRAdmission;
use Hash;
use Illuminate\Support\Str;
use Mail;

class AuthController extends Controller
{
    public function index()
    {
        if (Auth::check()) {
            $generaladmissions = Generaladmission::get();
            $gapitentries = GAPitentry::get();
            $pitentries = Pitentry::get();
            $dradmissions = DRAdmission::get();
            $eventlists = DB::table('eventlist')->where('eventstatus', 'Active')->first();
            return view('home', compact('generaladmissions', 'gapitentries', 'pitentries', 'dradmissions', 'eventlists'));
        }
        return view('auth.login');
    }
    public function postLogin(Request $request)
    {
        // echo "hi";exit;
        $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);
        $credentials = $request->only('email', 'password');
        $email = DB::table('users')->where("email", "=", $request->email)->get('email')->toArray();
        $password = DB::table('users')->where("password", "=", $request->password)->get('password')->toArray();
        // return $email;die;
        // return  $credentials;die;

        // print_r(Auth::attempt($credentials));exit;
        // if (Auth::attempt($credentials)) {
        //     return redirect("dashboard")
        //                 ->with('success','You have Successfully loggedin');
        // }
        if (Auth::attempt($credentials)) {
            return redirect("dashboard1")
                ->with('success', 'You have Successfully loggedin');
        } elseif (Auth::attempt($credentials) || empty($email) || empty($password)) {
            return redirect("/")
                ->with('error', 'Please enter valid credential');
        }
    }
    public function dashboard()
    {
        if (Auth::check()) {
            $generaladmissions = Generaladmission::get();
            $gapitentries = GAPitentry::get();
            $pitentries = Pitentry::get();
            $dradmissions = DRAdmission::get();
            $eventlists = DB::table('eventlist')->where('eventstatus', 'Active')->first();
            return view('home', compact('generaladmissions', 'gapitentries', 'pitentries', 'dradmissions', 'eventlists'));
        }

        return redirect("login")->withSuccess('Opps! You do not have access');
    }
    public function dashboard1()
    {
        if (Auth::check()) {

            $data = [];

            $eventlists = DB::table('eventlist')->where('eventstatus', 'Active')->first();

            if($eventlists->hosttrack == 'Carrick' && $eventlists->assignedpricelist == 'Standard'){
                $data = DB::table('ticketprices_carrick_standardevent')->get();

            }elseif($eventlists->hosttrack == 'Carrick' && $eventlists->assignedpricelist == 'Custom'){
                $data = DB::table('ticketprices_carrick_customevent')->get();

            }elseif($eventlists->hosttrack == 'Hobart' && $eventlists->assignedpricelist == 'Standard'){
                $data = DB::table('ticketprices_hobart_standardevent')->get();

            }elseif($eventlists->hosttrack == 'Hobart' && $eventlists->assignedpricelist == 'Custom'){
                $data = DB::table('ticketprices_hobart_customevent')->get();

            }elseif($eventlists->hosttrack == 'Latrobe' && $eventlists->assignedpricelist == 'Standard'){
                $data = DB::table('ticketprices_latrobe_standardevent')->get();

            }elseif($eventlists->hosttrack == 'Latrobe' && $eventlists->assignedpricelist == 'Custom'){
                $data = DB::table('ticketprices_latrobe_customevent')->get();

            }

            return view('home_new', compact('data', 'eventlists'));
        }

        return redirect("login")->withSuccess('Opps! You do not have access');
    }

    public function logout()
    {
        // Session::flush();
        Auth::logout();

        return Redirect('/');
    }
}
