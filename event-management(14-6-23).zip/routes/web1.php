<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\EventController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
// Route::get('/event', function () {
//     return view('events/index');
// });
// Auth::routes();
// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('dashboard', [AuthController::class, 'dashboard'])->middleware(['auth']);
Route::get('/', [AuthController::class, 'index'])->name('login');
Route::post('postLogin', [AuthController::class, 'postLogin'])->name('login.post');
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/tickets', [HomeController::class, 'tickets']);
Route::get('add-to-cart/{id}', [HomeController::class, 'addToCart'])->name('add.to.cart');
Route::get('add-to-cart1/{id}', [HomeController::class, 'addToCart1'])->name('add.to.cart1');
Route::get('add-to-cart2/{id}', [HomeController::class, 'addToCart2'])->name('add.to.cart2');
Route::get('add-to-cart3/{id}', [HomeController::class, 'addToCart3'])->name('add.to.cart3');
Route::patch('update-cart', [HomeController::class, 'update'])->name('update.cart');
Route::delete('remove-from-cart', [HomeController::class, 'remove'])->name('remove.from.cart');
Route::post('/eventspost', [EventController::class, 'store'])->name('events.store');
