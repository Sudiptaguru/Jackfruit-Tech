<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management System</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta property="og:title" content="" />
    <meta property="og:image" content="" />
    <meta property="og:description" content="" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#ffc618">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#ffc618">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#ffc618">
    <!-- favicon -->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <!-- icofont css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/icofont.min.css')); ?>" />
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/stylesheet.css')); ?>" />
</head>

<body class="dark-shade">
    <?php if(auth()->guard()->guest()): ?>
    <?php endif; ?>
    <section class="wrapper">
        <div class="container">

            <?php if(session('success')): ?>
            <div id="box" class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div id="box1" class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div id="box2" class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </section>
</body>
<!-- js area-->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

<!-- open camera for scanning  -->
<script src="<?php echo e(asset('assets/js/jsQR.js')); ?>"></script>
<!-- // -->

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- custom js -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script type="text/javascript">
    $(".update-cart").change(function(e) {
        e.preventDefault();

        var ele = $(this);

        $.ajax({
            url: "<?php echo e(route('update.cart')); ?>",
            method: "patch",
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                id: ele.parents("tr").attr("data-id"),
                quantity: ele.parents("tr").find(".quantity").val()
            },
            success: function(response) {
                window.location.reload();
            }
        });
    });

    $(".remove-from-cart").click(function(e) {
        e.preventDefault();

        var ele = $(this);

        if (confirm("Are you sure want to remove?")) {
            $.ajax({
                url: "<?php echo e(route('remove.from.cart')); ?>",
                method: "DELETE",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: ele.parents("tr").attr("data-id")
                },
                success: function(response) {
                    window.location.reload();
                }
            });
        }
    });
    setTimeout(() => {
        const box = document.getElementById('box');
        box.style.display = 'none';
    }, 1000);
    setTimeout(() => {
        const box1 = document.getElementById('box1');
        box1.style.display = 'none';
    }, 1000);
    setTimeout(() => {
        const box2 = document.getElementById('box2');
        box2.style.display = 'none';
    }, 1000);
</script>

</html>
<?php /**PATH C:\xampp\htdocs\event-management\resources\views/layouts/app.blade.php ENDPATH**/ ?>