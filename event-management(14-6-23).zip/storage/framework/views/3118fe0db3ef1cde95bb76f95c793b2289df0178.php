<?php $__env->startSection('content'); ?>
<!------ ticket area ----->
<section class="main-area ticket-area">
    <div class="container-fluid">
        <!-- header -->
        <div class="page-header-area">
            <div class="row">

                <div class="col-2">
                    <div class="qr-code">
                        <a href="#" id="open-modal">
                            <img src="assets/images/QR-Code.png" class="img-fluid" alt="QR Code" />
                        </a>
                    </div>
                </div>

                <!-- open modal for scan qr code -->

                <div id="modal">
                    <div id="modal-content">
                        <div id="scanner-container">
                            <video id="scanner-video"></video>

                            <svg class="app__scanner-img" width="310" height="310" viewBox="0 0 215 215" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: block;">
                                <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <g id="Artboard" transform="translate(-146.000000, -58.000000)" fill="#FFFFFF" fill-rule="nonzero">
                                        <g id="scanner" transform="translate(146.000000, 58.000000)">
                                            <path d="M169.272388,200.559701 L169.272388,194.141791 L169.272388,200.559701 Z M206.977612,169.272388 L213.395522,169.272388 L206.977612,169.272388 Z M197.751866,196.548507 L195.386866,194.380056 L197.751866,196.548507 Z M177.294776,215 C182.766045,215 188.646455,214.846772 193.977332,213.800653 C199.295373,212.757743 204.460187,210.752948 208.139254,206.739347 L203.409254,202.402444 C201.047463,204.977631 197.426959,206.583713 192.741884,207.503078 C188.07125,208.420037 182.731549,208.58209 177.294776,208.58209 L177.294776,215 Z M208.139254,206.739347 C211.515877,203.057071 213.159664,197.946007 214.013246,192.871045 C214.876455,187.740728 215,182.195653 215,177.294776 L208.58209,177.294776 C208.58209,182.153134 208.452127,187.240933 207.684384,191.806474 C206.907015,196.426567 205.543209,200.074347 203.409254,202.402444 L208.139254,206.739347 L208.139254,206.739347 Z M200.559701,37.7052239 L194.141791,37.7052239 L200.559701,37.7052239 Z M196.548507,9.22574627 L194.380056,11.5907463 L196.548507,9.22574627 Z M215,37.7052239 C215,32.2339552 214.846772,26.3535448 213.800653,21.0226679 C212.757743,15.7046269 210.752948,10.5398134 206.739347,6.86074627 L202.402444,11.5907463 C204.977631,13.9525373 206.583713,17.573041 207.503078,22.2581157 C208.420037,26.9295522 208.58209,32.2684515 208.58209,37.7052239 L215,37.7052239 Z M206.739347,6.86074627 C203.057071,3.48412313 197.946007,1.84033582 192.871045,0.986753731 C187.740728,0.123544776 182.195653,5.32907052e-15 177.294776,5.32907052e-15 L177.294776,6.41791045 C182.153134,6.41791045 187.240933,6.54787313 191.806474,7.31561567 C196.426567,8.09298507 200.074347,9.45759328 202.402444,11.5915485 L206.739347,6.86074627 Z M6.41791045,169.272388 L12.8358209,169.272388 L6.41791045,169.272388 Z M37.7052239,206.977612 L37.7052239,213.395522 L37.7052239,206.977612 Z M10.4291045,197.751866 L12.597556,195.386866 L10.4291045,197.751866 Z M-2.39808173e-14,177.294776 C-2.39808173e-14,182.766045 0.152425373,188.646455 1.19934701,193.977332 C2.24225746,199.295373 4.24705224,204.460187 8.26065299,208.139254 L12.597556,203.409254 C10.0223694,201.047463 8.41628731,197.426959 7.49692164,192.741884 C6.57996269,188.07125 6.41791045,182.731549 6.41791045,177.294776 L-2.39808173e-14,177.294776 Z M8.26065299,208.139254 C11.9429291,211.515877 17.0539925,213.159664 22.1289552,214.013246 C27.2600746,214.876455 32.8051493,215 37.7052239,215 L37.7052239,208.58209 C32.8468657,208.58209 27.7590672,208.452127 23.1943284,207.684384 C18.5734328,206.907015 14.925653,205.543209 12.597556,203.409254 L8.26065299,208.139254 L8.26065299,208.139254 Z M37.7052239,6.41791045 L37.7052239,12.8358209 L37.7052239,6.41791045 Z M9.22574627,10.4291045 L11.5907463,12.597556 L9.22574627,10.4291045 Z M37.7052239,0 C32.2339552,0 26.3535448,0.152425373 21.0226679,1.19934701 C15.7046269,2.24225746 10.5398134,4.24705224 6.86074627,8.26065299 L11.5907463,12.597556 C13.9525373,10.0223694 17.573041,8.41628731 22.2581157,7.49692164 C26.9295522,6.57996269 32.2684515,6.41791045 37.7052239,6.41791045 L37.7052239,0 Z M6.86074627,8.26065299 C3.48412313,11.9429291 1.84033582,17.0539925 0.986753731,22.1289552 C0.123544776,27.2600746 -1.42108547e-14,32.8051493 -1.42108547e-14,37.7052239 L6.41791045,37.7052239 C6.41791045,32.8468657 6.54787313,27.7590672 7.31561567,23.1943284 C8.09298507,18.5734328 9.45759328,14.925653 11.5915485,12.597556 L6.86074627,8.26065299 Z" id="Shape"></path>
                                        </g>
                                    </g>
                                </g>
                            </svg>

                            <div class="custom-scanner" style="display: block;"></div>
                            <div id="result-container"></div>
                        </div>
                        <span id="modal-close">&times;</span>
                    </div>
                </div>

                <!-- // -->

                <div class="col-6">
                    <div class="search-area">
                        <form class="formal-form" action="" method="post">
                            <div class="form-group">
                                <input type="search" class="form-control search" id="search" name="search" placeholder="Touch Here To Scan Ticket">
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-4 text-right">
                    <div class="dropdown">
                        <button class="btn btn-color dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Hi <?php echo e(Auth::user()->name); ?>

                            <i class="fa fa-user-circle-o drop-user"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#"><?php echo e(Auth::user()->name); ?></a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><?php echo e(__('Logout')); ?></a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="line">
                        <hr>
                    </div>
                </div>
            </div>
        </div>
        <!-- //header -->

        <!-- middle area -->
        <form action="<?php echo e(route('events.store')); ?>" method="POST">
            <div class="medium-area">
                <div class="row">
                    <div class="col-sm-12 col-lg-9">
                        <div class="ticket scroll-area">
                            <!-- GENERAL ADMISSION -->
                            <div class="row mt-2">
                                <div class="col-12 mb-3">
                                    <div class="category-name">
                                        <h1>GENERAL ADMISSION</h1>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $generaladmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $generaladmission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-3 custom-half">
                                    <a href="<?php echo e(route('add.to.cart', $generaladmission->id)); ?>">
                                        <div class="ticket-card ticketcolor<?php echo e($generaladmission->is_active); ?>">
                                            <span class="ticket-icon"><i class="icofont-ticket"></i></span>
                                            <h4><?php echo e($generaladmission->tickettype); ?></h4>
                                            <p><i class="icofont-dollar"></i> <?php echo e($generaladmission->ticketprice); ?></p>

                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <!-- GENERAL ADMISSION & PIT ENTRY -->
                            <div class="row mt-2">
                                <div class="col-12 mb-3">
                                    <div class="category-name">
                                        <h1>GENERAL ADMISSION & PIT ENTRY</h1>
                                    </div>
                                </div>
                                <?php $__currentLoopData = $gapitentries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gapitentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-3 custom-half">
                                    <a href="<?php echo e(route('add.to.cart1', $gapitentry->id)); ?>">
                                        <div class="ticket-card yellow-ticket">
                                            <span class="ticket-icon"><i class="icofont-ticket"></i></span>
                                            <h4><?php echo e($gapitentry->tickettype); ?></h4>
                                            <p><i class="icofont-dollar"></i> <?php echo e($gapitentry->ticketprice); ?></p>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <!-- PIT ENTRY ONLY -->
                            <div class="row mt-2">
                                <div class="col-12 mb-3">
                                    <div class="category-name">
                                        <h1>PIT ENTRY ONLY</h1>
                                    </div>
                                </div>
                                <?php $__empty_1 = true; $__currentLoopData = $pitentries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pitentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-6 col-lg-3 custom-half">
                                    <a href="<?php echo e(route('add.to.cart2', $pitentry->id)); ?>">
                                        <div class="ticket-card blue-ticket">
                                            <span class="ticket-icon"><i class="icofont-ticket"></i></span>
                                            <h4><?php echo e($pitentry->tickettype); ?></h4>
                                            <p><i class="icofont-dollar"></i> <?php echo e($pitentry->ticketprice); ?></p>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                            <!-- DRIVERS ADMISSION -->
                            <div class="row mt-2">
                                <div class="col-12 mb-3">
                                    <div class="category-name">
                                        <h1>DRIVERS ADMISSION</h1>
                                    </div>
                                </div>
                                <?php $__empty_1 = true; $__currentLoopData = $dradmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dradmission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-6 col-lg-3 custom-half">
                                    <a href="<?php echo e(route('add.to.cart3', $dradmission->id)); ?>">
                                        <div class="ticket-card green-ticket">
                                            <span class="ticket-icon"><i class="icofont-ticket"></i></span>
                                            <h4><?php echo e($dradmission->tickettype); ?></h4>
                                            <p><i class="icofont-dollar"></i> <?php echo e($dradmission->ticketprice); ?></p>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-lg-3">
                        <div class="side-bar">
                            <div class="row">
                                <div class="col-12 p-md-0 p-lg-0">
                                    <div class="category-name side-title">
                                        <h1>Transaction Summary</h1>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 p-md-0 p-lg-0">
                                    <!-- <div class="ticket-listing">
                                                <ul>
                                                    <li>
                                                        <div>
                                                            <span class="number-bg">1</span> Ticket Type x 2
                                                            <span class="price"><i class="icofont-dollar"></i> 64.00</span>
                                                        </div>
                                                        <div class="quantity-area">
                                                            <div class="number">
                                                                <span class="minus trig">-<span>
                                                                <input type="text" class="form-input" value="1"/>
                                                                <span class="plus trig">+</span>
                                                                <button class="btn btn-danger btn-sm rounded-0">Empty Ticket</button>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div>
                                                            <span class="number-bg">2</span> Ticket Type x 1
                                                            <span class="price"><i class="icofont-dollar"></i> 55.00</span>
                                                        </div>
                                                        <div class="quantity-area">
                                                            <div class="number">
                                                                <span class="minus trig">-<span>
                                                                <input type="text" class="form-input" value="1"/>
                                                                <span class="plus trig">+</span>
                                                                <button class="btn btn-danger btn-sm rounded-0">Empty Ticket</button>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div>
                                                            <span class="number-bg">3</span> Event Program x 1
                                                            <span class="price"><i class="icofont-dollar"></i> 155.00</span>
                                                        </div>
                                                        <div class="quantity-area">
                                                            <div class="number">
                                                                <span class="minus trig">-<span>
                                                                <input type="text" class="form-input" value="1"/>
                                                                <span class="plus trig">+</span>
                                                                <button class="btn btn-danger btn-sm rounded-0">Empty Ticket</button>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div>
                                                            <span class="number-bg">4</span> Ticket Type x 3
                                                            <span class="price"><i class="icofont-dollar"></i> 60.00</span>
                                                        </div>
                                                        <div class="quantity-area">
                                                            <div class="number">
                                                                <span class="minus trig">-<span>
                                                                <input type="text" class="form-input" value="1"/>
                                                                <span class="plus trig">+</span>
                                                                <button class="btn btn-danger btn-sm rounded-0">Empty Ticket</button>
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div> -->
                                    <div style="overflow: auto;">
                                        <table class="table table-borderless border-0 mt-3 my-table">
                                            <tbody>
                                                <?php $count=1;?>
                                                <?php $total = 0 ?>
                                                <?php if(session('cart')): ?>
                                                <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $total += $details['ticketprice'] * $details['quantity'] ?>
                                                <tr data-id="<?php echo e($id); ?>">
                                                    <td data-th="Tickettype">
                                                        <div class="table-details"><span class="number-bg"><?php echo e($count); ?></span> <span class="ticket-name"><?php echo e($details['tickettype']); ?> x <?php echo e($details['quantity']); ?></span></div>
                                                        <div class="quantity-area">
                                                            <div class="number">
                                                                <span class="minus trig">-<span>
                                                                        <!-- <input type="text" class="form-input" value="1" /> -->
                                                                        <input type="text" value="<?php echo e($details['quantity']); ?>" class="form-input quantity update-cart" />
                                                                        <span class="plus trig">+</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="table-price">
                                                            <span class="price"><i class="icofont-dollar"></i> $<?php echo e($details['ticketprice'] * $details['quantity']); ?></span>
                                                        </div>
                                                        <div class="empty-btn-div" style="float: right;">
                                                            <button class="btn btn-danger btn-sm rounded-0 remove-from-cart">Delete</button>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php $count++;?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 p-md-0 p-lg-0">
                                    <div class="subtotal-area dark-grey-bg mt-1">
                                        <?php echo csrf_field(); ?>
                                        <table class="table subtotal-table" border="0">
                                            <tbody>
                                                <tr>
                                                    <td>Subtotal</td>
                                                    <td><i class="icofont-dollar"></i> <?php echo e($total); ?><input name="subtotal" type="text" value="<?php echo e($total); ?>" style="display: none;"></td>
                                                </tr>
                                                <tr>
                                                    <td>GST 10% </td>
                                                    <td><i class="icofont-dollar"></i> <?php echo e(($total * 10)/100); ?><input name="gst" type="text" value="<?php echo e(($total * 10)/100); ?>" style="display: none;"></td>
                                                </tr>
                                                <tr>
                                                    <td>Total </td>
                                                    <td><i class="icofont-dollar"></i> <?php echo e($total + ($total * 10)/100); ?><input name="total" type="text" value="<?php echo e($total + ($total * 10)/100); ?>" style="display: none;"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <!-- payment area -->
                                        <div class="payment-area">
                                            <div class="title">
                                                <h5>Payment Method</h5>
                                            </div>
                                            <div class="main-method d-flex">
                                                <label for="method_one" class="whites">
                                                    <input type="radio" name="payment_method" id="method_one" value="Cash" checked> Cash
                                                </label>
                                                <label for="method_two" class="whites">
                                                    <input type="radio" name="payment_method" id="method_two" value="Card"> Card
                                                </label>
                                            </div>
                                        </div>
                                        <!-- button area -->
                                        <div class="button-area">
                                            <button type="submit" class="btn btn-light w-100 total-radius">COMPLETE</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- //middle area -->

            <!-- footer -->
            <div class="page-footer-area">
                <div class="row">
                    <div class="col-12">
                        <div class="line">
                            <hr>
                        </div>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col-2 custom-half">
                        <div class="event-name">
                            <h6>Active Event Date:</h6>
                        </div>
                    </div>


                    <div class="col-6 custom-half">
                        <div class="event-date">
                            <input type="" class="form-control search" id="event_date" name="event_date" value="<?php echo e($eventlists->eventdate); ?>">
                        </div>
                    </div>

                    <div class="col-4 d-sm-none d-md-none"></div>
                </div>
            </div>
        </form>
        <!--// footer -->
    </div>
</section>
<!-- end of ticket area -->
<!-------- back to top -------->
<a id="back2Top" title="Back To Top" href="#" style="display: inline;">
    <i class="icofont-swoosh-up back-to-i"></i>
</a>
<!--------// back to top ------>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\event-management\resources\views/home.blade.php ENDPATH**/ ?>