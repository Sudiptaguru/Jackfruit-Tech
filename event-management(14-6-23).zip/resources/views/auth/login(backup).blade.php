@extends('layouts.app')

@section('content')

<section class="wrapper">
    <!-- login body -->
    <section class="login-area">
        <div class="login-overly">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 offset-lg-3 align-self-center">
                        <div class="login-form-area text-center">
                            <div class="form-header">
                                <div class="site-logo">
                                    <img src="{{ asset('assets/images/logo.png') }}" class="img-fluid" alt="Event Management System Logo">
                                </div>
                                <h1 class="main-heading">Event Management System</h1>
                            </div>
                            <form class="formal-form" method="POST" action="{{ route('login') }}">
                                @csrf
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input class="form-control custom-field @error('email') is-invalid @enderror" id="email" type="email" name="email" placeholder="User Name" required autocomplete="email" autofocus>
                                            <i class="icofont-ui-user form-icon"></i>
                                            @error('email')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input class="form-control custom-field @error('password') is-invalid @enderror" id="password" type="password" name="password" required placeholder="Password" autocomplete="current-password">
                                            <i class="icofont-lock form-icon"></i>
                                            @error('password')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-login" value="LOGIN">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end of login body -->
</section>
<!-------- back to top -------->
<a id="back2Top" title="Back To Top" href="#" style="display: inline;">
    <i class="icofont-swoosh-up back-to-i"></i>
</a>

@endsection
