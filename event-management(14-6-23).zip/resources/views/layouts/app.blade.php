<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management System</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta property="og:title" content="" />
    <meta property="og:image" content="" />
    <meta property="og:description" content="" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#ffc618">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#ffc618">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#ffc618">
    <!-- favicon -->
    <link rel="icon" href="{{ asset('assets/images/favicon.png') }}">
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/bootstrap.min.css') }}" />
    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <!-- icofont css -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/icofont.min.css') }}" />
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/stylesheet.css') }}" />
</head>

<body class="dark-shade">
    @guest
    @endguest
    <section class="wrapper">
        <div class="container">

            @if(session('success'))
            <div id="box" class="alert alert-success">
                {{ session('success') }}
            </div>
            @endif
            @if(session('error'))
            <div id="box1" class="alert alert-danger">
                {{ session('error') }}
            </div>
            @endif
            @if ($errors->any())
            <div id="box2" class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
        </div>
        @yield('content')
    </section>
</body>
<!-- js area-->
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>

<!-- open camera for scanning  -->
<script src="{{ asset('assets/js/jsQR.js') }}"></script>
<!-- // -->

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<!-- custom js -->
<script src="{{ asset('assets/js/custom.js') }}"></script>
<script type="text/javascript">
    $(".update-cart").change(function(e) {
        e.preventDefault();

        var ele = $(this);

        $.ajax({
            url: "{{ route('update.cart') }}",
            method: "patch",
            data: {
                _token: '{{ csrf_token() }}',
                id: ele.parents("tr").attr("data-id"),
                quantity: ele.parents("tr").find(".quantity").val()
            },
            success: function(response) {
                window.location.reload();
            }
        });
    });

    $(".remove-from-cart").click(function(e) {
        e.preventDefault();

        var ele = $(this);

        if (confirm("Are you sure want to remove?")) {
            $.ajax({
                url: "{{ route('remove.from.cart') }}",
                method: "DELETE",
                data: {
                    _token: '{{ csrf_token() }}',
                    id: ele.parents("tr").attr("data-id")
                },
                success: function(response) {
                    window.location.reload();
                }
            });
        }
    });
    setTimeout(() => {
        const box = document.getElementById('box');
        box.style.display = 'none';
    }, 1000);
    setTimeout(() => {
        const box1 = document.getElementById('box1');
        box1.style.display = 'none';
    }, 1000);
    setTimeout(() => {
        const box2 = document.getElementById('box2');
        box2.style.display = 'none';
    }, 1000);
</script>

</html>
