<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management System</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta property="og:title" content="" />
    <meta property="og:image" content="" />
    <meta property="og:description" content="" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#ffc618">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#ffc618">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#ffc618">
    <!-- favicon -->
    <link rel="icon" href="assets/images/favicon.png">
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <!-- icofont css -->
    <link rel="stylesheet" type="text/css" href="assets/css/icofont.min.css" />
    <!-- custom css -->
    <link rel="stylesheet" type="text/css" href="assets/css/stylesheet.css" />
</head>

<body class="dark-shade">
@guest

@endguest
    @yield('content')
</body>
<!-- js area-->
<script src="assets/js/jquery.min.js"></script>

<!-- open camera for scanning  -->
<script src="assets/js/jsQR.js"></script>
<!-- // -->

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<!-- custom js -->
<script src="assets/js/custom.js"></script>

</html>
