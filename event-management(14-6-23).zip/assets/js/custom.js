// Back to top
$(window).scroll(function () {
    var height = $(window).scrollTop();
    if (height > 100) {
        $('#back2Top').fadeIn();
    } else {
        $('#back2Top').fadeOut();
    }
});
$(document).ready(function () {
    $("#back2Top").click(function (event) {
        event.preventDefault();
        $("html, body").animate({
            scrollTop: 0
        }, "slow");
        return false;
    });
});

// scanning qrcode developed by Raju

    $(document).ready(function() {
        
        const video = document.getElementById('scanner-video');
        const resultContainer = document.getElementById('result-container');
        const openModalButton = document.getElementById('open-modal');
        const closeModalButton = document.getElementById('modal-close');
        const modal = document.getElementById('modal');
        let scanInterval;
    
        openModalButton.addEventListener('click', function() {
        openScannerModal();
        });
    
        closeModalButton.addEventListener('click', function() {
        closeScannerModal();
        });
    
        function openScannerModal() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
            video.srcObject = stream;
            video.play();
            modal.style.display = 'block';
            scanInterval = setInterval(scanQRCode, 100);
            })
            .catch(function(error) {
            console.error('Error accessing the camera: ', error);
            });
        }
    
        function closeScannerModal() {
        clearInterval(scanInterval);
        video.srcObject.getTracks().forEach(track => track.stop());
        modal.style.display = 'none';
        }
    
        function scanQRCode() {
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            
            if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
            const code = jsQR(imageData.data, imageData.width, imageData.height);
            if (code) {
                resultContainer.innerText = code.data;
                clearInterval(scanInterval);
                video.srcObject.getTracks().forEach(track => track.stop());
    
                closeScannerModal();
                alert('QR code scanned successfully!');
                alert(code.data);
                
            }
            
            }
        }
    
    });

//
$(document).ready(function() {
    $('.minus').click(function () {
        var $input = $(this).parent().find('.form-input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
        $input.change();
        return false;
    });
    $('.plus').click(function () {
        var $input = $(this).parent().find('.form-input');
        $input.val(parseInt($input.val()) + 1);
        $input.change();
        return false;
    });
});



